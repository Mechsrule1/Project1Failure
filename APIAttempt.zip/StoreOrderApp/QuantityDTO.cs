﻿namespace StoreOrderApp.DTO
{
    public class QuantityDTO
    {
        public int ItemId { get; set; }
        public int Quantity { get; set; }
    }
}
